<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
  </body>
  <script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      window.location.replace('<?php echo base_url(); ?>Graphic-Web-Design-Company');
    });
  </script>
</html>
